# Cập nhật dropdown, dữ liệu và mail — 18/10/2026

## Cách cập nhật bản mới và nạp dữ liệu

1. Dừng backend/frontend. Chép đè `backend`, `frontend` và `CAP-NHAT-VA-NAP-DU-LIEU.cmd` từ ZIP vào đúng folder dự án hiện tại. Giữ `backend/.env`, uploads và DB.
2. Chạy `CAP-NHAT-VA-NAP-DU-LIEU.cmd`. Tệp này chạy `npm ci` **cả backend lẫn frontend**, rồi nạp dữ liệu qua API vào DB cấu hình trong `.env`. Không tạo lại DB, không xóa dữ liệu. Cần DB đã migration và có Admin hiện đang dùng.
3. Khi được hỏi email, nhập email tài khoản đang test nếu không dùng Admin. Lệnh thêm riêng một bộ khách hàng/liên hệ/cơ hội/báo giá cho tài khoản đó; nếu là Sales còn có lead được phân công. Không đổi vai trò, nhóm hoặc mật khẩu tài khoản hiện có. Admin có thể bỏ trống để dùng bộ chung.
4. Đọc số lượng bản ghi và kết quả SMTP ở cuối cửa sổ. Khởi động lại backend/frontend, nhấn Ctrl+F5. Bộ chọn nay là **nút mở danh sách**; gõ tìm trong ô tìm kiếm bên trong danh sách. Không biến giá trị đã chọn thành ô nhập.

Nếu chạy terminal thay tệp CMD: `npm ci` trong mỗi thư mục backend/frontend, rồi tại backend chạy `npm run data:examples`. Trên PowerShell, có thể đặt `$env:CRM_EXAMPLE_OWNER_EMAIL='email-tai-khoan-dang-test'` trước lệnh nạp; bỏ biến nếu dùng Admin. Mật khẩu 8 tài khoản KT mới nằm trong tệp riêng tư mà lệnh in đường dẫn, không nằm trong ZIP. Dữ liệu là bản ghi kiểm thử lưu thật trong DB, không phải danh tính/khách hàng đã xác minh.

## Gửi email thật

`npm run mail:check` tại backend kiểm tra cấu hình, kết nối và xác thực SMTP thật, **không gửi thư**. Thiếu `SMTP_HOST` thì chỉ có `SMTP_USER`/`SMTP_PASS` chưa đủ. Không dùng thông tin gửi thư của dự án khác hoặc thông tin có sẵn trong source.

Ví dụ nếu bạn dùng Gmail, chỉnh các mục tương ứng trong `.env` của bạn:

```dotenv
SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=your_email@gmail.com
SMTP_PASS=YOUR_GMAIL_APP_PASSWORD
SMTP_FROM="Enterprise CRM <your_email@gmail.com>"
FRONTEND_URL=http://localhost:5173
RUN_WORKER=true
```

Thay email/App Password bằng cấu hình riêng tại máy bạn; không gửi bí mật lên chat/Git. Nếu dùng nhà cung cấp khác, dùng host/cổng/TLS của nhà cung cấp đó. `FRONTEND_URL` phải trùng địa chỉ frontend đang mở. Khởi động lại backend sau khi chỉnh.

Admin vào Quản trị người dùng sẽ thấy SMTP thiếu mục nào, số thư đang chờ, số được SMTP nhận và mã lỗi gần nhất; có nút làm mới. SMTP nhận thư chưa đồng nghĩa thư đã tới Inbox. Khi test tạo user/quên mật khẩu, dùng email do bạn kiểm soát, kiểm tra cả Spam. Worker kiểm tra khoảng 30 giây, lỗi sẽ thử lại; `RUN_WORKER=false` thì phải chạy `npm run worker` riêng. Lỗi tác vụ lead/báo cáo không chặn mail nữa.

Tạo user gửi thông tin tài khoản/mật khẩu tạm qua SMTP; quên mật khẩu gửi liên kết dùng một lần trong 30 phút. Phản hồi quên mật khẩu luôn chung để không lộ email có tồn tại hay không. Đã kiểm thử hai luồng qua socket SMTP cục bộ thật, SMTP từ chối/tiếp nhận và retry; chưa truy cập hộp thư hoặc cấu hình SMTP trên máy bạn.

## Hướng dẫn cập nhật thủ công trước đó

Dừng hai terminal backend/frontend bằng Ctrl+C. Giải nén ZIP bản vá, chép hai thư mục `backend` và `frontend` vào folder `TTCS_N1` đang dùng, đồng ý thay tệp trùng. Giữ file `backend/.env`, uploads và database đang đăng nhập được. ZIP không chứa thông tin riêng tư đó.

Bản ZIP mới sửa dropdown và Excel, đồng thời gồm các bản sửa UI trước đó. Chạy `npm ci` để bảo đảm dependency ExcelJS đã có. Chạy trong terminal backend:

```powershell
npm ci
npm run dev
```

Trong terminal frontend:

```powershell
npm ci
npm run dev
```

Tải lại bằng Ctrl+F5. Không cần tạo lại DB hay chạy migration cho bản này. Không chạy lại SQL tạo database cũ. Giữ nguyên cấu hình DB/JWT/SMTP của bạn.

## Dropdown, dữ liệu chọn và Excel — bản bổ sung

- Mọi bộ chọn có mũi tên mở danh sách bằng chuột/bàn phím và tìm theo tên, không phân biệt hoa/thường hay dấu tiếng Việt. Ngành nghề, quy mô, khu vực, nguồn, chiến dịch, khách hàng, liên hệ và người phụ trách lấy từ DB theo quyền đang đăng nhập. Form hiển thị trạng thái tải và cho thử lại nếu API lỗi.
- Lần chạy backend đầu tiên sau cập nhật sẽ bổ sung danh mục chuẩn: ngành nghề, khoảng nhân sự, nguồn lead, loại hoạt động và ba miền. Đây là các bản ghi danh mục lưu trong DB; không tạo user/khách hàng/lead/cơ hội. Giữ các mục có sẵn, chỉ khởi tạo một lần; khởi động lại không phục hồi mục bạn chủ động xóa. Có thể chạy riêng `npm run data:catalogs` trong backend. `INIT_REFERENCE_CATALOGS=false` tắt khởi tạo tự động.
- Khách hàng, lead và cơ hội chọn được các dữ liệu liên kết rồi lưu thật. Khu vực trong lead là danh sách lấy từ DB. Khi danh mục được thêm mới, mở lại form để tải danh sách cập nhật.
- “Thêm mức quy mô doanh nghiệp” là thêm khoảng nhân sự dùng chung, ví dụ “51–200 nhân sự”. Trong form có liên kết mở **Thêm khách hàng/doanh nghiệp**, nơi nhập tên doanh nghiệp thực tế.
- Xuất Excel khách hàng, lead và báo giá nháp dùng worksheet đơn giản: tiêu đề tiếng Việt, cột có độ rộng rõ, đường viền, bộ lọc, cố định hàng đầu; không còn bảng XML/comment/VML phức tạp. File rỗng vẫn có tiêu đề. Số tiền là số; điện thoại/MST là văn bản để giữ số 0 đầu.
- **Tải lại file Excel mới sau khi cập nhật**, không dùng lại file cũ đã bị Excel sửa. Mẫu người dùng có đúng sáu cột: Tên, Email, Mật khẩu tạm thời, Vai trò (RBAC), Nhóm kinh doanh, Số điện thoại. Nhập nhóm đúng tên đã tồn tại; mật khẩu để trống sẽ tự sinh, nếu nhập phải đạt quy tắc mật khẩu. Không xuất mật khẩu/hash của tài khoản có sẵn.
- Thao tác lưu/xuất có icon loading và thông báo hoàn tất/lỗi; chuyển thẻ và mở/đóng form có animation, tôn trọng cài đặt giảm chuyển động.

## Các điểm cần test

- Bấm avatar: menu Hồ sơ cá nhân / Đổi mật khẩu / Đăng xuất. Hồ sơ sửa tên, điện thoại, ảnh JPG/PNG tối đa 2 MB và chữ ký. Email, nhóm và vai trò chỉ xem trong hồ sơ; Admin quản lý tài khoản ở màn hình Quản trị người dùng.
- Bấm chuông: thông báo riêng của tài khoản. Admin/Director còn có nhật ký thao tác nhạy cảm bằng văn bản và nút xem toàn bộ nhật ký. Vai trò không có quyền nhật ký không nhận dữ liệu nhật ký từ API.
- Admin có toàn quyền các module, gồm giá vốn. Các vai trò khác giữ quyền theo User Roles. Nhật ký là lịch sử chỉ đọc cho mọi vai trò, Admin vẫn thực hiện các thao tác nghiệp vụ để tạo nhật ký mới.
- Thêm nguồn lead/ngành nghề/quy mô/loại hoạt động: tên và hướng dẫn phù hợp từng loại, mã có thể bỏ trống để hệ thống tạo duy nhất. Danh mục dùng chung được làm mới khi mở form hoặc sau khi lưu dữ liệu.
- Sales chọn được tên chiến dịch trong lead/cơ hội. API chọn chiến dịch chỉ trả mã và tên, không mở quyền xem ngân sách/báo cáo chiến dịch.
- Form lead có người phụ trách cho vai trò được phân bổ. Đổi người phụ trách cập nhật nhóm, thời hạn SLA và thông báo cùng giao dịch lưu; không được phân bổ vượt phạm vi nhóm. Form khách hàng có người phụ trách và công ty mẹ.
- Ngừng kinh doanh sản phẩm: bấm biểu tượng cấm → Xác nhận → trạng thái đổi và còn đúng sau F5; có thể kinh doanh trở lại. Báo giá cũ giữ nguyên.
- Cơ cấu tổ chức: thẻ Cây nhóm kinh doanh và Cây công ty mẹ/con. Bộ chọn cha loại chính nó và nhánh con. Cây công ty chỉ hiện dữ liệu theo phạm vi được xem.
- Mẫu Excel/xuất khách hàng và lead: có bảng, bộ lọc, cố định tiêu đề, độ rộng cột, hướng dẫn và danh mục mã cho mẫu nhập. Tiêu đề tiếng Việt; vẫn đọc được file cũ dùng `company_name`, `source_id`… Trường tùy chỉnh giữ mã trường. Nhập vẫn phải xem trước và xử lý trùng trước khi lưu.
- Tiền có dấu chấm nhóm nghìn, lịch lưu ngày thực, kiểm tra ngày kết thúc không trước ngày bắt đầu. Giữ animation và chế độ giảm chuyển động.

## Email tạo tài khoản và quên mật khẩu

Tạo người dùng bằng màn hình Admin hoặc Nhập Excel: hệ thống dùng mật khẩu tạm hợp lệ đã nhập hoặc tự sinh ngẫu nhiên nếu để trống, lưu hash và đưa email đăng nhập/mật khẩu tạm/liên kết đặt mật khẩu vào hàng đợi SMTP. Tài khoản phải đổi mật khẩu lần đầu. Không dùng mật khẩu chung mặc định.

Quên mật khẩu tại màn hình đăng nhập: nhập email của tài khoản đang hoạt động. Email chứa liên kết đặt mật khẩu có hiệu lực 30 phút, chỉ dùng một lần. Phản hồi UI giống nhau dù email có tồn tại hay không.

Để thư được gửi thật, `backend/.env` cần `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM`; `FRONTEND_URL` phải trỏ tới địa chỉ frontend bạn đang mở. Với Gmail: host `smtp.gmail.com`, port `465`, secure `true`, mật khẩu ứng dụng trong `SMTP_PASS`. Giữ worker chạy (mặc định đi kèm backend; không đặt `RUN_WORKER=false`). Worker kiểm tra khoảng 30 giây, gửi lỗi sẽ thử lại. Dòng “đã gửi yêu cầu” trên UI không chứng minh thư đã đến hộp thư.

Đã kiểm thử qua máy chủ SMTP cục bộ thật; chưa truy cập Gmail/SMTP hay hộp thư trên máy bạn. Không gửi App Password vào chat. Khi thử mail thật, dùng email bạn kiểm soát.

## Dữ liệu kiểm thử đã có

Với bản mới, chạy `npm run data:examples` để bổ sung dữ liệu chọn và dữ liệu liên kết vào DB đang dùng; tệp CMD phía trên đã thực hiện bước này. Tài khoản, dữ liệu liên kết và mật khẩu riêng nằm ở đường dẫn lệnh in ra; xem `backend/docs/EXAMPLE-DATA.md`. Dữ liệu KT là ví dụ kiểm thử, không phải khách hàng hay danh tính đã xác minh.
