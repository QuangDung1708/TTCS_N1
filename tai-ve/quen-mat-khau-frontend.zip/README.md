# N1-277 — frontend — Triệu Quang Dũng

Gói này chỉ chứa code frontend của tính năng quên mật khẩu, không có CRM.

## Push bằng tài khoản của bạn

Giải nén vào một thư mục mới, trống, nằm ngoài repository CRM cũ. Mở terminal ở thư mục giải nén (thư mục chứa frontend). KHÔNG clone develop hoặc copy cả repository CRM vào đây.

```sh
git init -b frontend/quen-mat-khau-mau
git config user.name "Tên của bạn"
git config user.email "Email GitHub đã xác minh của bạn"
git add .
git diff --cached --stat
git commit -m "N1-277: them frontend quen mat khau"
git remote add origin https://github.com/QuangDung1708/TTCS_N1.git
git push -u origin frontend/quen-mat-khau-mau
```

Đăng nhập GitHub bằng tài khoản của chính bạn, có quyền push repo. Nếu cùng tên nhánh đã tồn tại, dùng tên mới; không force push lên nhánh của người khác. Không commit node_modules, .env, dữ liệu và email demo.

Đây là nhánh độc lập cho bản mẫu. Khi xem nhánh này GitHub chỉ hiện code trong gói, không có lịch sử/code CRM. Không merge vào develop như nhánh tính năng thông thường vì lịch sử độc lập.

## Ghép và chạy

Ghép backend và frontend cạnh nhau trong một thư mục riêng, không đặt frontend bên trong backend:

```
backend/
frontend/
```

Cần Node.js >=20. Trong backend chạy `npm ci`, `npm run seed`, `npm start`; mở http://localhost:5055. Bấm Quên mật khẩu?, nhập sales@example.test. Email demo được lưu trong backend/outbox/. Mở tệp mới nhất để lấy link. Không mở frontend bằng file://.

## Frontend

Chỉ nút Quên mật khẩu? và dialog form email / mật khẩu mới / xác nhận. Có hiện ẩn mật khẩu, loading, countdown, thông báo lỗi và thành công. HTML/CSS/JS thuần, responsive, animation nhẹ. Không chứa đăng nhập, dashboard, slogan hay màn hình khác.

Cần ghép với backend của Danh để test đầy đủ. Đã test Chromium desktop/mobile: gửi email demo, đổi mật khẩu, từ chối link đã dùng, xác nhận không khớp và email không tồn tại.
